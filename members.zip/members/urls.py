from django.conf import  settings
from django.urls import  path
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('login/',views.Login.as_view(),name='login'),
    path('profile/<int:id>/',views.Profile.as_view(),name='profile'),
    path('edit-profile/<int:id>',views.Edit_Profile.as_view(),name='edit_profile'),
    path('usr/<int:id>/', views.RegUser.as_view() , name='userhome'), 
] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)